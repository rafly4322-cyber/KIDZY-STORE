======================================================
KIDZY STORE � SAWERIA ROBLOX LIFETIME PACKAGE V2.0
======================================================

CARA PEMASANGAN DI ROBLOX STUDIO:
1. Buka Roblox Studio dan buka Game/Experience kamu.
2. Buka Game Settings -> Security -> Aktifkan:
   - Allow HTTP Requests = ON
   - Enable Studio Access to API Services = ON
3. Import file 'Saweria_V2_KIDZY.rbxm' ke dalam Workspace / ServerScriptService.
4. Masukkan URL Webhook atau Polling URL dari Dashboard KIDZY Store ke dalam script config.
5. Jalankan Play test dan nikmati donasi otomatis realtime!

Support via Discord: https://discord.gg/tqnreKW6D8
Owner: Muhammad Rafly (KIDZY)
======================================================
